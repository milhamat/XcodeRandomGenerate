# .JUMPA

[![Language](http://img.shields.io/badge/language-swift-brightgreen.svg?style=flat)](https://developer.apple.com/swift)

.Jumpa - App for increasing commitment of experienced volunteer in Volunteering Community.

## Requirements

- Xcode 11
- iOS 13+


## How to build

## How to use

## Known Issues

- N/A

## Author

**IhwanID**

 Swift, Kotlin & Flutter Developer | Associate Android Developer | Sharing @codewithihwan

- GitHub  [IhwanID](https://github.com/IhwanID)
- Social: [Twitter](https://twitter.com/Ihwan_ID) / [LinkedIn](https://www.linkedin.com/in/ihwanid/)

**Elmysf**

 Developer | Python | Swift

- GitHub  [Elmysf](https://github.com/elmysf)
- Social: [Twitter](https://twitter.com/Elmysf__) / [LinkedIn](https://www.linkedin.com/in/sufiandyelmy/)

**Moh Iwangga KS**

 Swift | Fisheries Product Technology

- GitHub  [Iwanggawae](https://github.com/iwanggawae)
- Social: [LinkedIn](https://www.linkedin.com/in/moh-iwangga-kalih-syah-p-281284108/)

**Franky C Johari**

 Swift | System Information

- GitHub  [Franky](https://github.com/Franky-Johari)
- Social: [LinkedIn](https://www.linkedin.com/in/franky-johari-31b5a8118/)


**Annisa Noranda Barezky**

 Swift | Design | industrial Engineering

- Social: [LinkedIn](https://www.linkedin.com/in/annisa-noranda-barezky-54b144161/)

**H.A.I.N Wahyoe**

 Swift | Design | Event Organizer

- Social: [LinkedIn](https://www.linkedin.com/in/askwhy/)


