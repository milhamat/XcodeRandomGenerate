# .JUMPA

[![Language](http://img.shields.io/badge/language-swift-brightgreen.svg?style=flat)](https://developer.apple.com/swift)

.Jumpa - App for increasing commitment of experienced volunteer in Volunteering Community.

## Requirements

- Xcode 11
- iOS 13+
- MacOS 10.15

## How to build

## How to use

.Jumpa app in that there are two applications, the first is for iOS as a user and the second is for Macbook as admin

## Known Issues

- N/A

## Author

**IhwanID**

 Swift, Kotlin & Flutter Developer | Associate Android Developer | Sharing @codewithihwan

 <a href="https://github.com/IhwanID" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/github.svg" height="20" /></a>&nbsp;
 <a href="https://www.linkedin.com/in/ihwanid/" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/linkedin.svg" height="20" /></a>&nbsp;
 <a href="https://twitter.com/Ihwan_ID" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/twitter.svg" height="20" /></a>&nbsp;
 <a href="https://www.youtube.com/channel/UCjntzibNSsjjIOh0HoP9vxw" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/youtube.svg" height="20" /></a>&nbsp;

**Elmysf**

 Developer | Python | Swift

 <a href="https://github.com/elmysf" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/github.svg" height="20" /></a>&nbsp;
 <a href="https://www.linkedin.com/in/sufiandyelmy/" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/linkedin.svg" height="20" /></a>&nbsp;
 <a href="https://twitter.com/Elmysf__" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/twitter.svg" height="20" /></a>&nbsp;
 <a href="https://youtu.be/rpaZ7SXZXbU" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/youtube.svg" height="20" /></a>&nbsp;

**Moh Iwangga Kalih Syah Putra**

 Swift | Fisheries Product Technology

 <a href="https://github.com/iwanggawae" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/github.svg" height="20" /></a>&nbsp;
 <a href="https://www.linkedin.com/in/moh-iwangga-kalih-syah-p-281284108/" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/linkedin.svg" height="20" /></a>&nbsp;
  <a href="https://www.facebook.com/iwa.275?__tn__=%2CdlC-R-R&eid=ARASjlywMNqtbc_2_pnXf1flKru8Jm2JwOFmQ6qTktJVkTvKoEqJPIfU5LuFJjgqOB8WZWbAIeB5DCtG&hc_ref=ARRE7v9_dW98jsyhDLNwXlsLyFWpCDcwWXFEX8mD5Lu0PPF5qav7NPDRNDvsCVAa-4w" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/facebook.svg" height="20" /></a>&nbsp;
 
**Annisa Noranda Barezky**

 Swift | Design | industrial Engineering

 <a href="https://www.linkedin.com/in/annisa-noranda-barezky-54b144161/" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/linkedin.svg" height="20" /></a>&nbsp;

**H.A.I.N Wahyoe**

 Swift | Design | Event Organizer

 <a href="https://www.linkedin.com/in/askwhy/" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/linkedin.svg" height="20" /></a>&nbsp;

**Franky C Johari**

 Swift | System Information

<a href="https://github.com/Franky-Johari" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/github.svg" height="20" /></a>&nbsp;
<a href="https://www.linkedin.com/in/franky-johari-31b5a8118/" target="blank"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.4.0/icons/linkedin.svg" height="20" /></a>&nbsp;
