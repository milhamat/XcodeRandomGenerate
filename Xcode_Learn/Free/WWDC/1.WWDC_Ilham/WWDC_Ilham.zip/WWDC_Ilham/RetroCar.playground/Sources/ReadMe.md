hi 👋😁 my name is ilham
as person who born in 90's era. it's kind good to experience nostalgic in retro game 👾🎮 so in this opportunity i try to make a simple retro game since i am new to swift language environment i try my best i can do so here is RetroCar 🕹🚗

so basically it's never ending game you just a voiding oponent car and get a hight score and it's only move horizontally  😆
